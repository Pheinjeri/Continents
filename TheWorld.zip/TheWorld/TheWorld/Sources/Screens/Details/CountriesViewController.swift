//
//  CountriesViewController.swift
//  TheWorld
//
//  Created by Faith on 10/6/21.
//

import UIKit
import RxSwift
import RxCocoa

class CountriesViewController: UIViewController {
    @IBOutlet weak var tablewView: UITableView!
    let viewModel = ContinentsViewModel()
    var selectedContinent = ""
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
    }
    func setUpTableView(){
        self.title = selectedContinent
       
        let backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationItem.backBarButtonItem = backBarButtonItem
        
        viewModel.countries.bind(to: tablewView.rx.items(cellIdentifier: "CountriesTableViewCell", cellType: CountriesTableViewCell.self)){
            (row, item, cell) in
            
            cell.configureUi(item: item)
        }.disposed(by: disposeBag)
        viewModel.fetchCountriesFromContinent(continent: selectedContinent)
    }
    

}
