//
//  CountriesTableViewCell.swift
//  TheWorld
//
//  Created by Faith on 10/6/21.
//

import UIKit

class CountriesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var countriesLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func configureUi(item: String){
        countriesLabel.text = item
    }

}
