//
//  ContinentTableViewCell.swift
//  TheWorld
//
//  Created by Faith on 10/6/21.
//

import UIKit

class ContinentTableViewCell: UITableViewCell {

    @IBOutlet weak var continentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configureUi(item: String){
        continentLabel.text = item
    }

}
