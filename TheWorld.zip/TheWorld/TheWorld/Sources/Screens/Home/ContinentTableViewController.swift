//
//  ViewController.swift
//  TheWorld
//
//  Created by Faith on 10/6/21.
//

import UIKit
import RxSwift
import RxCocoa

class ContinentTableViewController: UIViewController {
    @IBOutlet weak var tablewView: UITableView!
    
    let viewModel = ContinentsViewModel()
    var selectedContinent: String = ""
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
    }
    func setUpTableView(){
        viewModel.continents.bind(to: tablewView.rx.items(cellIdentifier: "ContinentTableViewCell", cellType: ContinentTableViewCell.self)){
            (row, item, cell) in
            cell.selectionStyle = .none
            cell.configureUi(item: item)
        }.disposed(by: disposeBag)
        
    

        tablewView.rx.modelSelected(String.self).subscribe(onNext: {
            item in
            print("selected \(item)")
            self.selectedContinent = item
            self.performSegue(withIdentifier: "ContinentToCountriesViewController", sender: nil)
        }).disposed(by: disposeBag)
        viewModel.fetchMyContinentsList()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ContinentToCountriesViewController"{
            if let destinantion = segue.destination as? CountriesViewController {
                destinantion.selectedContinent = selectedContinent

            }
        }
    }

}

