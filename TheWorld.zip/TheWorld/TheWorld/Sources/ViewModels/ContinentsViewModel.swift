//
//  ContinentsViewModel.swift
//  TheWorld
//
//  Created by Faith on 10/6/21.
//

import Foundation
import RxSwift
import RxCocoa

let bigData = ["Asia": ["Singapore", "Macao", "Kazakhstan", "Malaysia", "Afghanistan", "Oman", "Mongolia", "Israel", "Tajikistan", "Philippines", "Kyrgyzstan", "Jordan", "China", "Hong Kong", "Qatar", "Iraq", "Sri Lanka", "Myanmar", "Palestine", "Thailand", "Bhutan", "Cambodia", "Bangladesh", "Syria", "Indonesia", "Iran", "Bahrain", "Saudi Arabia", "Georgia", "Turkey", "Uzbekistan", "Yemen", "Vietnam", "Lebanon", "Azerbaijan", "North Korea", "Kuwait", "East Timor", "Maldives", "Pakistan", "Cyprus", "India", "United Arab Emirates", "Japan", "Armenia", "Laos", "South Korea", "Turkmenistan", "Brunei", "Nepal"], "Europe": ["Czech Republic", "San Marino", "North Macedonia", "Croatia", "Netherlands", "Slovakia", "Hungary", "Serbia", "United Kingdom", "Faroe Islands", "Bulgaria", "Spain", "Belgium", "Germany", "Bosnia and Herzegovina", "Romania", "France", "Latvia", "Lithuania", "Monaco", "Malta", "Belarus", "Norway", "Italy", "Luxembourg", "Greece", "Slovenia", "Switzerland", "Holy See (Vatican City State)", "Finland", "Gibraltar", "Northern Ireland", "Scotland", "Ireland", "Albania", "Moldova", "England", "Portugal", "Estonia", "Sweden", "Svalbard and Jan Mayen", "Liechtenstein", "Poland", "Denmark", "Montenegro", "Russian Federation", "Wales", "Ukraine", "Andorra", "Austria", "Iceland"], "Africa": ["Sao Tome and Principe", "Western Sahara", "Togo", "Congo", "Ghana", "Guinea", "Guinea-Bissau", "Reunion", "Niger", "Djibouti", "Somalia", "Tunisia", "Chad", "Malawi", "Mauritania", "Seychelles", "Mauritius", "Benin", "Ethiopia", "Zimbabwe", "Burkina Faso", "Liberia", "South Africa", "Senegal", "The Democratic Republic of Congo", "Algeria", "Kenya", "Equatorial Guinea", "Egypt", "Mayotte", "Gabon", "Nigeria", "Zambia", "Sierra Leone", "Mozambique", "Ivory Coast", "British Indian Ocean Territory", "Botswana", "Libyan Arab Jamahiriya", "Swaziland", "Saint Helena", "Gambia", "Cape Verde", "Sudan", "Uganda", "South Sudan", "Burundi", "Comoros", "Rwanda", "Angola", "Madagascar", "Namibia", "Cameroon", "Eritrea", "Lesotho", "Central African Republic", "Mali", "Morocco", "Tanzania"], "Oceania": [
                    "New Zealand", "Cook Islands", "Vanuatu", "Guam", "American Samoa", "Fiji Islands", "Cocos (Keeling) Islands", "French Polynesia", "Samoa", "Australia", "Palau", "Christmas Island", "Kiribati", "United States Minor Outlying Islands", "Norfolk Island", "Solomon Islands", "Tonga", "Nauru", "Niue", "Micronesia, Federated States of", "Tokelau", "Pitcairn", "Wallis and Futuna", "Papua New Guinea", "Northern Mariana Islands", "New Caledonia", "Marshall Islands", "Tuvalu"], "North America": ["Anguilla", "Dominican Republic", "Saint Pierre and Miquelon", "United States", "Virgin Islands, British", "Martinique", "Trinidad and Tobago", "Netherlands Antilles", "Turks and Caicos Islands", "Belize", "Cuba", "El Salvador", "Costa Rica", "Nicaragua", "Puerto Rico", "Saint Vincent and the Grenadines", "Virgin Islands, U.S.", "Bermuda", "Canada", "Panama", "Montserrat", "Mexico", "Honduras", "Saint Lucia", "Aruba", "Antigua and Barbuda", "Guatemala", "Cayman Islands", "Dominica", "Greenland", "Saint Kitts and Nevis", "Jamaica", "Bahamas", "Haiti", "Barbados", "Guadeloupe", "Grenada"], "Antarctica": ["Heard Island and McDonald Islands", "French Southern territories", "Antarctica", "South Georgia and the South Sandwich Islands", "Bouvet Island"], "South America": ["Chile", "Falkland Islands", "Venezuela", "Uruguay", "Colombia", "Bolivia", "Argentina", "Ecuador", "Peru", "Suriname", "Brazil", "Paraguay", "Guyana", "French Guiana"]]

class ContinentsViewModel{
    let continents = PublishSubject<[String]>()
    let countries = PublishSubject<[String]>()
    
   
    func fetchMyContinentsList(){
        var continentList = [String]()
        for continent in bigData.keys {
            continentList.append(continent)
        }
        continentList.sort()
        continents.onNext(continentList)
        continents.onCompleted()
    }
    
    func fetchCountriesFromContinent(continent: String){
        if var countryList = bigData[continent] {
            countryList.sort()
            countries.onNext(countryList)
            countries.onCompleted()
        }
    }
}
